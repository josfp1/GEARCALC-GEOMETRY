// Netlify serverless function — proxy para Geometry Geeks
// Evita el bloqueo CORS al hacer fetch desde el servidor en lugar del navegador
// Rutas:
//   GET /api/geometry?action=search&q=Trek+Emonda
//   GET /api/geometry?action=bike&slug=trek-emonda-slr-7-2021

export default async (req) => {
  const url   = new URL(req.url);
  const action = url.searchParams.get("action");

  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
  };

  try {

    // ── SEARCH ────────────────────────────────────────────────────────────────
    if (action === "search") {
      const q = url.searchParams.get("q") || "";
      if (!q.trim()) return Response.json({ results: [] }, { headers });

      // Geometry Geeks tiene un endpoint de búsqueda en su API interna
      const searchUrl = `https://geometrygeeks.bike/bike-directory/search/?q=${encodeURIComponent(q)}`;
      const res = await fetch(searchUrl, {
        headers: { "User-Agent": "Mozilla/5.0", "Accept": "text/html" }
      });
      const html = await res.text();

      // Parsear resultados — están en links con formato /bike/slug/
      const matches = [...html.matchAll(/href="\/bike\/([^"]+)"[^>]*>\s*([^<]{3,80})</g)];
      const seen = new Set();
      const results = [];

      for (const m of matches) {
        const slug = m[1].replace(/\/$/, "");
        if (seen.has(slug)) continue;
        seen.add(slug);
        // Limpiar el nombre
        const name = m[2].trim().replace(/\s+/g, " ");
        if (name.length < 3) continue;
        results.push({ slug, name });
        if (results.length >= 12) break;
      }

      return Response.json({ results }, { headers });
    }

    // ── BIKE DATA ─────────────────────────────────────────────────────────────
    if (action === "bike") {
      const slug = url.searchParams.get("slug") || "";
      if (!slug) return Response.json({ error: "slug requerido" }, { headers, status: 400 });

      const bikeUrl = `https://geometrygeeks.bike/bike/${slug}/`;
      const res = await fetch(bikeUrl, {
        headers: { "User-Agent": "Mozilla/5.0", "Accept": "text/html" }
      });
      const html = await res.text();

      // Extraer nombre de la bici
      const nameMatch = html.match(/<h1[^>]*>\s*([^<]+)\s*<\/h1>/);
      const bikeName  = nameMatch ? nameMatch[1].trim() : slug;

      // Mapa de campos a parsear
      const rowMap = {
        "Reach":                "reach",
        "Stack":                "stack",
        "Top Tube (effective)": "topTube",
        "Top Tube":             "topTube",
        "Seat Tube C-T":        "seatTube",
        "Seat Tube":            "seatTube",
        "Head Angle":           "headAngle",
        "Seat Angle":           "seatAngle",
        "Head Tube":            "headTube",
        "Chainstay":            "chainstay",
        "Wheelbase":            "wheelbase",
        "BB Drop":              "bbDrop",
        "Fork Rake / Offset":   "forkRake",
        "Trail":                "trail",
        "Standover":            "standover",
        "Front Centre":         "frontCentre",
      };

      // Parsear tabla HTML
      const rows   = {};
      let   sizes  = [];

      const trMatches = [...html.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)];

      for (const tr of trMatches) {
        const cells = [...tr[1].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)]
          .map(m => m[1]
            .replace(/<[^>]+>/g, "")
            .replace(/&amp;/g, "&").replace(/&nbsp;/g, " ")
            .replace(/&[a-z]+;/g, "")
            .trim()
          );

        if (cells.length < 2) continue;

        // Detectar fila de tallas
        const sizeRe = /^\d{2,3}(\s*cm)?$|^(XS|S|M|L|XL|XXL|2XL|3XL)$/i;
        if (cells.slice(1).some(c => sizeRe.test(c.trim()))) {
          sizes = cells.slice(1)
            .map(c => c.trim())
            .filter(c => sizeRe.test(c) || c === "");
          // Keep only non-empty
          sizes = sizes.filter(Boolean);
          continue;
        }

        const label = cells[0];
        const key   = rowMap[label];
        if (key && !rows[key]) {
          rows[key] = cells.slice(1).map(v => {
            const n = parseFloat(v.replace(",", "."));
            return isNaN(n) ? null : n;
          });
        }
      }

      // Fallback: infer sizes from column count
      if (sizes.length === 0 && Object.keys(rows).length > 0) {
        const colCount = Object.values(rows)[0].length;
        sizes = Array.from({ length: colCount }, (_, i) => `Talla ${i + 1}`);
      }

      return Response.json({ bikeName, sizes, rows }, { headers });
    }

    return Response.json({ error: "Acción desconocida" }, { headers, status: 400 });

  } catch (err) {
    console.error("geometry fn error:", err);
    return Response.json({ error: err.message }, { headers, status: 500 });
  }
};

export const config = { path: "/api/geometry" };
